<?php



// exercice 4 

echo $_COOKIE["password"] . "<br>";
echo $_COOKIE["email"];

// var_dump($_COOKIE);

?>

<a href="index.php" class="btn btn-danger">Retour</a>