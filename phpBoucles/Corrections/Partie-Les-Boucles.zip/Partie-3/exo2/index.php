<?php
$var2 = 5;
for ($var1 = 0; $var1 <= 20; $var1++) {
    echo nl2br($var1 * $var2 . "\n");
}

$var1 = 0;
$var2 = 12;
while ($var1 <= 20) {
    echo nl2br($var1 * $var2 . "\n");
    $var1++;
}

?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

</body>

</html>