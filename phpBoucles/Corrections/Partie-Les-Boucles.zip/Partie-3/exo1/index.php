<?php
for ($var = 0; $var <= 10; $var++) {
    echo $var;
}

echo "<br>";

$var = 0;
while ($var <= 10) {
    echo $var;
    $var++;
}

?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

</body>

</html>